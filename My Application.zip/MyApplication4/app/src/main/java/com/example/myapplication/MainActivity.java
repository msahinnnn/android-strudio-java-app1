package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    String kulAdi;
    String kulSifre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn1;
        EditText usrname;
        EditText pass;

        btn1 = (Button) findViewById(R.id.btnGiris);
        usrname = (EditText) findViewById(R.id.kullaniciAdi);
        pass = (EditText) findViewById(R.id.sifre);


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Veri Tabanı bağlantılarını daha işlemediğimiz için
                //default kullanıcı adı : admin - default şifre : admin olarak alındı

                kulAdi = usrname.getText().toString();
                kulSifre = pass.getText().toString();
                String admin = "admin";

                if(kulAdi.equals("admin")){
                    if(kulSifre.equals("admin")){
                        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                        startActivity(intent);
                    }
                }
                else{
                    Toast.makeText(getApplicationContext(),"Giriş Başarısız",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}